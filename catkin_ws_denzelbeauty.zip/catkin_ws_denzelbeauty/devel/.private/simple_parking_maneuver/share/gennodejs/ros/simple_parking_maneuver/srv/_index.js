
"use strict";

let ParkingManeuver = require('./ParkingManeuver.js')

module.exports = {
  ParkingManeuver: ParkingManeuver,
};
